package com.app.listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.app.utility.*;

/**
 * Application Lifecycle Listener implementation class SessionFactoryManager
 *
 */
@WebListener
public class SessionFactoryManager implements ServletContextListener {

    

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
    	System.out.println("ctx destroyed");
        HibernateUtils.getSf().close();
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
        System.out.println("ctx inited");
        HibernateUtils.getSf();
    }
	
}
