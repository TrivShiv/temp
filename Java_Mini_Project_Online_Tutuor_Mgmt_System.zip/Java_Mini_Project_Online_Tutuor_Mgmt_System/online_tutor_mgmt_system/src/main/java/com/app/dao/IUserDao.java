package com.app.dao;

import com.app.model.Student;
//import com.app.model.Student;
import com.app.model.Tutor;

public interface IUserDao {

	Student validateStudent(String studmname, String studpwd);
	Tutor validateTutor(String tutorname, String tutorpwd);
	Tutor getTutor(int tutorId);
	Student getStudent(int studId);
	String saveStudent(Student student);
	String saveTutor(Tutor tutor);
	String changeStudentStaus(int id);
	String changeTutorStaus(int id);
    
}

