package com.app.dao;

import org.hibernate.*;
import static com.app.utility.HibernateUtils.getSf;

import java.io.Serializable;

import com.app.model.Status;
import com.app.model.Student;
import com.app.model.StudentTutorMapping;
import com.app.model.Tutor;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;

public class UserDaoImpl implements IUserDao {

	public Student validateStudent(String studmname, String studpwd) {
		
		String jpql = "select s from Student s where s.studName=:username and s.studPwd=:password";
		
		Session hibSession=getSf().getCurrentSession();
		
		Transaction tx=hibSession.beginTransaction();
		Student student = null;
		try {
			student = hibSession.createQuery(jpql, Student.class).setParameter("username", studmname).setParameter("password", studpwd)
					.getSingleResult();
			tx.commit();
		
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return student;
	}

	public Tutor validateTutor(String tutorname, String tutorpwd) {
		
		String jpql = "select t from Tutor t where t.tutorName=:username and t.tutorPwd=:password";
		Session hibSession=getSf().getCurrentSession();
		
		Transaction tx=hibSession.beginTransaction();
		Tutor tutor = null;
		try {
			tutor = hibSession.createQuery(jpql, Tutor.class).setParameter("username", tutorname).setParameter("password", tutorpwd)
					.getSingleResult();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return tutor;
	}
	
	public Student getStudent(int studId) {
		Session session=getSf().getCurrentSession();
		Transaction tx=session.beginTransaction();
		Student detaildStud = null;
		try {
			 detaildStud = session.get(Student.class, studId);
			tx.commit();
			System.out.println("get student data from db ");
		}catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return detaildStud;
	}

	
	public Tutor getTutor(int tutorId) {
		Session session=getSf().getCurrentSession();
		Transaction tx=session.beginTransaction();
		Tutor detaildTutor = null;
		try {
			detaildTutor = session.get(Tutor.class, tutorId); 
			tx.commit();
			System.out.println("get tutor data from db ");
		}
		catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return detaildTutor;
	}

	public String saveStudent(Student student) {
		Session hibSession=getSf().getCurrentSession();
		String msg = "failed";
		Transaction tx=hibSession.beginTransaction();
		try {
			hibSession.persist(student);
			tx.commit();
		    msg="success";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

	public String saveTutor(Tutor tutor) {
		Session hibSession=getSf().getCurrentSession();
		String msg = "failed";
		Transaction tx=hibSession.beginTransaction();
		try {
			hibSession.persist(tutor);
			tx.commit();
			msg="success";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

	public String changeStudentStaus(int id) {
		Session hibSession=getSf().getCurrentSession();
		String msg = "failed";
		Transaction tx=hibSession.beginTransaction();
		Student student = null;
		try {
			student = hibSession.get(Student.class,id);
			LocalDateTime joinedAt = LocalDateTime.now();
			student.setStatus(Status.APPROVED);
			student.setJoinedAt(joinedAt);
			tx.commit();
			msg="success";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

	public String changeTutorStaus(int id) {
		Session hibSession=getSf().getCurrentSession();
		String msg = "failed";
		Transaction tx=hibSession.beginTransaction();
		Tutor tutor = null;
		try {
			tutor = hibSession.get(Tutor.class,id);
			LocalDateTime joinedAt = LocalDateTime.now();
			tutor.setStatus(Status.APPROVED);
			tutor.setJoinedAt(joinedAt);
			tx.commit();
			msg="success";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

	
	}


