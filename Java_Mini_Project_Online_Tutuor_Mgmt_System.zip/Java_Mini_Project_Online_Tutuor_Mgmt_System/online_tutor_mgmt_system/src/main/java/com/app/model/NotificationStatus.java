package com.app.model;

public enum NotificationStatus {
   NOTCHECKD,CHECK
}
