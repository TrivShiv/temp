package com.app.controller;

import java.io.IOException;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.Role;
import com.app.model.Student;
import com.app.model.StudentTutorMapping;
import com.app.model.Tutor;
import com.app.services.StudentServiceImpl;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet(urlPatterns="/getStudentDetails",loadOnStartup=1)
public class GetRequestedStudentList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private StudentServiceImpl studentServiceImpl;
	private StudentDao studentdaoImpl;
	private TutorDaoImpl tutorDao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetRequestedStudentList() {
    	
        super();
        System.out.println("in get requested tutor servlet");
		
		studentServiceImpl = new StudentServiceImpl();
		studentdaoImpl = new StudentDao();
		tutorDao= new TutorDaoImpl();
		
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		String msg = studentServiceImpl.checkedRequest();
		if(msg.equals("success")) {
			Tutor tutor =  studentServiceImpl.getTutor((Integer)session.getAttribute("tutor_id"));
			   Set<StudentTutorMapping> reequestStudentList= studentServiceImpl.getRequestStudentList(tutor);
			   request.setAttribute("tutor_name", tutor.getTutorName());
			   request.setAttribute("requeststudentlist", reequestStudentList );
			   RequestDispatcher rd = request.getRequestDispatcher("studentlist.jsp");
			   rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
