package com.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import javax.servlet.*;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.Role;
import com.app.model.Student;
import com.app.model.Tutor;
import com.app.services.StudentServiceImpl;
import com.app.services.UserServiceImpl;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet("/uploadStudentImage")
@MultipartConfig
public class uploadStudentImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public uploadStudentImage() {
    	
        super();
        System.out.println("in student servlet");
		
		
		
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		pw.print("hi form upload id : "+request.getParameter("studImageFile"));
		System.out.println("in student image upload servlet");
		System.out.println(request.getParameter("studImageFile"));
		
		Part filePart = request.getPart("studImageFile");
		System.out.println("file part : "+filePart);
		String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); 
		// MSIE fix.
		String filepath = Paths.get(filePart.getSubmittedFileName()).getFileSystem().toString();
		InputStream fileContent = filePart.getInputStream();
		System.out.println("filename : "+fileName);
		System.out.println("filepath : "+filepath);
		System.out.println("fileContent : "+fileContent);
		
//		 FileInputStream input = null;
//	        File theFile = new File(request.getParameter("studImageFile"));
//	        input = new FileInputStream(theFile);
//	        System.out.println("FullPathname" + " " + theFile.getAbsolutePath());
	        
//	        ServletContext context = PageContext.getServletContext();
//	        String filePath = context.getInitParameter("file-upload");
		
				
	}
	
}
