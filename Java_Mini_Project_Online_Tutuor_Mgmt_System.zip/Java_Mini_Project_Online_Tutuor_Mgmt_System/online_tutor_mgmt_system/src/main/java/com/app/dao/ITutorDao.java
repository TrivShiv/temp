package com.app.dao;

import java.util.List;
import java.util.Set;

import com.app.model.StudentNotification;
import com.app.model.TrainingMaterial;
import com.app.model.Tutor;
import com.app.model.TutorNotification;

public interface ITutorDao {

	Set<TrainingMaterial> getTrainingListByTutor(Tutor tutor);
	List<TrainingMaterial> getAllTrainingMaterialByTutorId(int id);
	String deleteTutor(String id);
	String acceptRequestedStudent(int studId,int tutId); 
	String addStudentNotification(StudentNotification studentNotification);
	Number acceptRequestCount(int studId);
	String checkedRequest();
	
}
