package com.app.controller;

import java.io.IOException;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.Role;
import com.app.model.Student;
import com.app.model.StudentTutorMapping;
import com.app.model.Tutor;
import com.app.services.StudentServiceImpl;
import com.app.services.TutorServiceImpl;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet(urlPatterns="/getTutorDetails",loadOnStartup=1)
public class GetRequestedTutorList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private StudentServiceImpl studentServiceImpl;
	private StudentDao studentdaoImpl;
	private TutorDaoImpl tutorDao;
	private TutorServiceImpl tutorServicempl;
       
    public GetRequestedTutorList() {
    	
        super();
        System.out.println("in get requested tutor servlet");
        tutorServicempl = new TutorServiceImpl();
		studentServiceImpl = new StudentServiceImpl();
		studentdaoImpl = new StudentDao();
		tutorDao= new TutorDaoImpl();
		
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
   
		   String msg = tutorServicempl.checkedRequest();
			if(msg.equals("success")) {

				Student student =  studentServiceImpl.getStudent((Integer)session.getAttribute("student_id"));
				   Set<StudentTutorMapping> reequestTutorList= studentServiceImpl.getRequestTutorList(student);
				   request.setAttribute("requesttutorlist", reequestTutorList );
				   RequestDispatcher rd = request.getRequestDispatcher("tutorlist.jsp");
				   rd.forward(request, response);
			}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
	}

}
