package com.app.services;

import java.util.List;
import java.util.Set;

import com.app.model.Student;
import com.app.model.StudentTutorMapping;
import com.app.model.Tutor;
import com.app.model.TutorNotification;

public interface IStudentService {
	String registerUser(Student student);
	List<Tutor> getAllTutors();
	
	Set<StudentTutorMapping> getRequestTutorList(Student student);
	Set<StudentTutorMapping> getRequestStudentList(Tutor tutor);
	String addStudent(Student student,Tutor tutor);
	Tutor getTutor(int tutorId);
	Student getStudent(int studId);
	List<Tutor> getAllTutorsBySearch(String name);
	String addTutorNotification(TutorNotification tutorNotification);
	Number pendingRequestCount(int tutorId);
	String checkedRequest();
}
