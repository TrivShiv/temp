package com.app.services;

import java.util.List;
import java.util.Set;

import com.app.dao.ITutorDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.StudentNotification;
import com.app.model.TrainingMaterial;
import com.app.model.Tutor;

public class TutorServiceImpl implements ITutorService {

	private TutorDaoImpl tutorDaoImpl;
	
	public TutorServiceImpl(){
		tutorDaoImpl = new TutorDaoImpl();
	}
	
	
	public Set<TrainingMaterial> getTrainingMaterialListByTutor(Tutor tutor) {
		return tutorDaoImpl.getTrainingListByTutor(tutor);
	}


	public String acceptRequestedStudent(int studId, int tutId) {
		return tutorDaoImpl.acceptRequestedStudent(studId, tutId);
	}


	public Number acceptRequestCount(int studId) {
		
		return tutorDaoImpl.acceptRequestCount(studId);
	}


	public String checkedRequest() {
		
		return tutorDaoImpl.checkedRequest();
	}


	public String addStudentNotification(StudentNotification studentNotification) {
		
		return tutorDaoImpl.addStudentNotification(studentNotification);
	}

}
