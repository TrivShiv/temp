package com.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.Role;
import com.app.model.Status;
import com.app.model.Student;
import com.app.model.Tutor;
import com.app.services.StudentServiceImpl;
import com.app.services.TutorServiceImpl;
import com.app.services.UserServiceImpl;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet("/signIn")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private StudentServiceImpl studentServiceImpl;
	private StudentDao studentdaoImpl;
	private TutorDaoImpl tutorDao;
	private UserServiceImpl userServiceImpl;
	private TutorServiceImpl tutorServicempl;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
    	
        super();
        System.out.println("in sign in servlet");
		
		studentServiceImpl = new StudentServiceImpl();
		studentdaoImpl = new StudentDao();
		tutorDao= new TutorDaoImpl();
		userServiceImpl = new UserServiceImpl();
		tutorServicempl = new TutorServiceImpl();
		
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("role : "+request.getParameter("role"));
		System.out.println("name : "+request.getParameter("usrname"));
		System.out.println("pwd : "+request.getParameter("pwd"));
		HttpSession session = request.getSession();
		RequestDispatcher  rd;
		
		if(request.getParameter("role").equals("student"))
		{
			Student student = userServiceImpl.validateStudent(request.getParameter("usrname"), request.getParameter("pwd"));
			
			if(student != null && student.getStatus().equals(Status.APPROVED)) {
				List<Tutor> listOfTutor=studentServiceImpl.getAllTutors();

				session.setAttribute("student_name", student.getStudName());
				session.setAttribute("student_id", student.getStudId());
				session.setAttribute("stud_detail", student);
				
				
				Number count= tutorServicempl.acceptRequestCount(student.getStudId());
				System.out.println("total count student id : "+student.getStudId()+" accept count : "+count);
				request.setAttribute("pendingRequestCount", count);
				request.setAttribute("tutorList", listOfTutor);
				rd = request.getRequestDispatcher("view/student/studentDashboard.jsp");
				rd.forward(request, response);
			
			}
			else {
				request.setAttribute("errmsg", "Please Activate Your Account");
				rd = request.getRequestDispatcher("SignIn.jsp");
				rd.forward(request, response);
			}
		}
		if(request.getParameter("role").equals("tutor")) {
			Tutor tutor = userServiceImpl.validateTutor(request.getParameter("usrname"), request.getParameter("pwd"));

			if(tutor != null && tutor.getStatus().equals(Status.APPROVED)) {
				
				Number count= studentServiceImpl.pendingRequestCount(tutor.getTutorId());
				System.out.println("in dao total count tutor id : "+tutor.getTutorId()+" pending count : "+count);
				
				session.setAttribute("tutor_name", tutor.getTutorName());
				request.setAttribute("tutor_name", tutor.getTutorName());
				request.setAttribute("pendingRequestCount", count);
				session.setAttribute("tutor_id", tutor.getTutorId());
				rd = request.getRequestDispatcher("view/tutor/tutorDashboard.jsp");
				rd.forward(request, response);
			}
			else {
				request.setAttribute("errmsg", "Please Activate Your Account");
				rd = request.getRequestDispatcher("SignIn.jsp");
				rd.forward(request, response);
			}
		}
		

		if(request.getParameter("role").equals("admin")) {
			if(request.getParameter("usrname").equals("admin") &&
				request.getParameter("pwd").equals("admin@123")) {

				request.setAttribute("adminName", request.getParameter("usrname"));
				rd = request.getRequestDispatcher("view/admin/adminPage.jsp");
				rd.forward(request, response);
			}

			}
		}
		
		
		
	
}
