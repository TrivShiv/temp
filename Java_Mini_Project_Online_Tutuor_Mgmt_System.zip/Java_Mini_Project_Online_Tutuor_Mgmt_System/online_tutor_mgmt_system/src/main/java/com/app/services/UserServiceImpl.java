package com.app.services;

import com.app.dao.UserDaoImpl;
import com.app.model.Student;
import com.app.model.Tutor;

public class UserServiceImpl implements IUserService {
	
	private UserDaoImpl userDaoImpl;

	public UserServiceImpl() {
		super();
		this.userDaoImpl = new UserDaoImpl();
	}

	public Student validateStudent(String studmname, String studpwd) {
		return userDaoImpl.validateStudent(studmname, studpwd);
	}

	public Tutor validateTutor(String tutorname, String tutorpwd) {
		
		return userDaoImpl.validateTutor(tutorname, tutorpwd);
	}

	public Tutor getTutor(int tutorId) {
		return userDaoImpl.getTutor(tutorId);
	}

	public Student getStudent(int studId) {
		return userDaoImpl.getStudent(studId);
	}

	public String saveStudent(Student student) {
		return userDaoImpl.saveStudent(student);
	}

	public String saveTutor(Tutor tutor) {		
		return userDaoImpl.saveTutor(tutor);
	}

	public String changeStudentStaus(int id) {
		return userDaoImpl.changeStudentStaus(id);
	}

	public String changeTutorStaus(int id) {
		return userDaoImpl.changeTutorStaus(id);
	}

}
