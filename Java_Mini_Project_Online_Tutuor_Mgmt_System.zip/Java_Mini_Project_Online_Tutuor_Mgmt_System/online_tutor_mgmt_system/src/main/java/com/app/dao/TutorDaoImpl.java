package com.app.dao;

import static com.app.utility.HibernateUtils.getSf;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.model.NotificationStatus;
import com.app.model.Status;
import com.app.model.Student;
import com.app.model.StudentNotification;
import com.app.model.StudentTutorMapping;
import com.app.model.TrainingMaterial;
import com.app.model.Tutor;
import com.app.model.TutorNotification;

import org.hibernate.query.Query;

public class TutorDaoImpl implements ITutorDao{

	public String registerUser(Tutor tutor) {
		System.out.println("in student dao");
		String message="User registration failed...";
		// 1. get hibernate Session from SessionFactory : openSession
		Session hibSession=getSf().getCurrentSession();
		
		// 2 begin a transaction (tx)
		Transaction tx=hibSession.beginTransaction();//hib pools out DB connection,wraps db cn in Session ,
		//L1 cache is created in empty manner
		try {
			hibSession.save(tutor);
			tutor.setStatus(Status.valueOf("NOTAPPROVED"));
			//success : commit
			tx.commit();
			message="User registered successfully with ID "+tutor.getTutorId();
		} catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			//inform /alert the caller about exception : re throw the SAME exception to caller (tester)
			throw e;
		} finally {
			if(hibSession != null)
				hibSession.close();//L1 cache is destroyed n pooled out DB cn rets to the connection pool , 
			//so that SAME DB connection can be reused for another request.
				
		}
		return message;
	}

	public List<TrainingMaterial> getAllTrainingMaterialByTutorId(int id) {
		
		
String jpql = "select m from TrainingMaterial m join fetch Tutor t on m.tutor = t.tutorId where t.tutor_id:=id";
//select m.material_id,m.content_type ,m.tutor_id from onlinetutormgmtsystem.training_material m inner join onlinetutormgmtsystem.tutor t  on m.tutor_id = t.tutor_id where t.tutor_id=2;

		
		Session hibSession=getSf().getCurrentSession();
		
		Transaction tx=hibSession.beginTransaction();
		List<TrainingMaterial> listMaterial = null;
		try {
			listMaterial = hibSession.createQuery(jpql, TrainingMaterial.class).setParameter("id", id).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return listMaterial;
	}
	
	
public Set<TrainingMaterial> getTrainingListByTutor(Tutor tutor){
		return tutor.getCreatedTrainingMaterials();
	}

public Tutor getTutor(int tutorId) {
//	String mesg="get student details failed";
	//session
	Session session=getSf().getCurrentSession();
	
	//tx
	Transaction tx=session.beginTransaction();
	Tutor detaildTutor = null;
	try {
		//c : transient
		detaildTutor = session.get(Tutor.class, tutorId);//persistent 
		tx.commit();//dirty chking : insert , session closed
		System.out.println("get tutor data from db ");
//		mesg="get details";
	}catch (RuntimeException e) {
		if(tx != null)
			tx.rollback();
		throw e;
	}
	return detaildTutor;
}

public String deleteTutor(String id) {
	String msg ="not able to remove tutor";
 StudentTutorMapping studtutmap = new StudentTutorMapping();
//	String jpql="select t from Tutor t join fetch Category c on c.tutors = t.tutorId join fetch TrainingMaterial m on m.tutor = t.tutorId join fetch StudentTutorMapping st on st.tutor = t.tutorId where t.tutorId=:id";
	String jpql = "select t from Tutor t where t.tutorName=:id";
	Tutor tutor = null;
	
	Session session=getSf().getCurrentSession();
	Transaction tx=session.beginTransaction();
	try {
		
		tutor = session.createQuery(jpql,Tutor.class).setParameter("id", id).getSingleResult();
		studtutmap.removeTutorOnly(tutor);
		
		session.saveOrUpdate(studtutmap);
		session.delete(tutor);
		msg ="Tutor removed";
	tx.commit();
	} catch (RuntimeException e) {
		tx.rollback();
		throw e;
	}
	return msg;
}

public String deleteStudent(int id) {
	   Student student = null;
	   String msg = "not able to deleted student";
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			Query<?> q=session.createQuery("delete from Student s where s.studId=:id");
			q.setParameter("id", id);
			int i = q.executeUpdate();
			msg="student removed";
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		} finally {
			session.close();
		}
		return msg;
	}

public String acceptRequestedStudent(int studId,int tutId) {
	Session hibSession=getSf().getCurrentSession();
	String msg = "failed";
//	select stm.student_tutor_id,stm.student_id,stm.tutor_id,stm.status
//	from onlinetutormgmtsystem.student_tutor_mapping stm inner join  
//	onlinetutormgmtsystem.student s on stm.student_id  = s.stud_id 
//	where stm.tutor_id=2 and stm.student_id=10;
	
//	[select stm from com.app.model.StudentTutorMapping stm join fetch Student s on stm.student = s.studId where s.studId:=studId
			
//	String jpql = "select stm from StudentTutorMapping stm join fetch Student s on stm.student = s.studId where s.studId=:studId join fetch Tutor t on stm.tutor = t.tutorId where ";
	String jpql = "select stm from StudentTutorMapping stm join fetch Student s on stm.student = s.studId join fetch Tutor t on stm.tutor = t.tutorId where  s.studId=:studId and t.tutorId =:tutId";
	Transaction tx=hibSession.beginTransaction();
	StudentTutorMapping studentTutorMapping = null;
	try {
		studentTutorMapping = hibSession.createQuery(jpql,StudentTutorMapping.class).setParameter("studId", studId).setParameter("tutId", tutId).getSingleResult();
		LocalDateTime accessAt = LocalDateTime.now();
		studentTutorMapping.setStatus(Status.APPROVED);
		studentTutorMapping.setAccessAt(accessAt);
		tx.commit();
		msg="success";
	} catch (RuntimeException e) {
		if (tx != null)
			tx.rollback();
		throw e;
	}
	return msg;
}

public Number acceptRequestCount(int studId) {
	Session hibSession=getSf().getCurrentSession();
	Number count;
	Transaction tx=hibSession.beginTransaction();
	try {
		Query<?> query=hibSession.createQuery("select COUNT (n.notificationId) from StudentNotification n where n.studId=:studId and n.notificationStatus=:staus");
		query.setParameter("studId", studId);
		query.setParameter("staus", NotificationStatus.NOTCHECKD);
		count=(Number) query.getSingleResult();
		System.out.println("in dao total count studId id : "+studId+" request count : "+count);
		tx.commit();
	} catch (RuntimeException e) {
		if (tx != null)
			tx.rollback();
		throw e;
	}
	return count;
}

public String checkedRequest() {
	Session hibSession=getSf().getCurrentSession();
	String msg="failed";
	List<StudentNotification> studentNotification = null;
	String jpql = "select n from StudentNotification n where n.notificationStatus=:status";
	Transaction tx=hibSession.beginTransaction();
	try {
		studentNotification = hibSession.createQuery(jpql,StudentNotification.class).setParameter("status", NotificationStatus.NOTCHECKD).getResultList();
		studentNotification.forEach(new Consumer<StudentNotification>() {
			public void accept(StudentNotification n) {
				n.setNotificationStatus(NotificationStatus.CHECK);
			}
		});
		tx.commit();
		msg="success";
	} catch (RuntimeException e) {
		if (tx != null)
			tx.rollback();
		throw e;
	} 
	return msg;
}

public String addStudentNotification(StudentNotification studentNotification) {
	Session hibSession=getSf().getCurrentSession();
	String msg = "failed";
	Transaction tx=hibSession.beginTransaction();
	try {
		hibSession.persist(studentNotification);
		tx.commit();
	    msg="success";
	} catch (RuntimeException e) {
		if (tx != null)
			tx.rollback();
		throw e;
	}
	return msg;
}

//public String deleteTutor(String id) {
//	// TODO Auto-generated method stub
//	return null;
//}

//public String deleteTutor(String id) {
//	String msg = "not able to remove tutor";
//	Session session = getSf().getCurrentSession();
//	Transaction tx = session.beginTransaction();
//	StudentTutorMapping studtutmap = new StudentTutorMapping();
//	try {
//		Query<?> q=session.createQuery("delete from Tutor t where t.tutorName=:id");
//		q.setParameter("id", id);
//		int i = q.executeUpdate();
//		msg="Tutor removed";
//		tx.commit();
//
//	} catch (RuntimeException e) {
//		if (tx != null)
//			tx.rollback();
//		throw e;
//	} finally {
//		session.close();
//	}
//	return msg;
//}

}
