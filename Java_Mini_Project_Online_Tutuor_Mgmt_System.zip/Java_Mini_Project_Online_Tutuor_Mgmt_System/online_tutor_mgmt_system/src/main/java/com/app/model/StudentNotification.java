package com.app.model;
import java.io.Serializable;


import javax.persistence.*;

@Entity
@Table(name="student_notification")
public class StudentNotification implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="notification_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int notificationId;
	
	@Column(name="student_id")
	private int studId;
	
	@Column(name="tutor_id")
	private int tutorId;
	
	@Enumerated(EnumType.ORDINAL)
	@Column(name="status")
	NotificationStatus notificationStatus;
	
	public StudentNotification() {
		super();
	}

	public StudentNotification(int studId, int tutorId, NotificationStatus notificationStatus) {
		super();
		this.studId = studId;
		this.tutorId = tutorId;
		this.notificationStatus = notificationStatus;
	}

	public int getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public int getTutorId() {
		return tutorId;
	}

	public void setTutorId(int tutorId) {
		this.tutorId = tutorId;
	}

	public NotificationStatus getNotificationStatus() {
		return notificationStatus;
	}

	public void setNotificationStatus(NotificationStatus notificationStatus) {
		this.notificationStatus = notificationStatus;
	}

	@Override
	public String toString() {
		return "TutorNotification [notificationId=" + notificationId + ", studId=" + studId + ", tutorId=" + tutorId
				+ ", notificationStatus=" + notificationStatus + "]";
	}
	
	
	

}
