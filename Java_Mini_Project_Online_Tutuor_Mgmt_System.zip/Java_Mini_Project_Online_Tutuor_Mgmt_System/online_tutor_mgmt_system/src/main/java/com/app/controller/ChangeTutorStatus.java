package com.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.Role;
import com.app.model.Student;
import com.app.model.Tutor;
import com.app.services.AdminServiceImpl;
import com.app.services.StudentServiceImpl;
import com.app.services.UserServiceImpl;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet("/changeTutStatus")
public class ChangeTutorStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private StudentServiceImpl studentServiceImpl;
	private StudentDao studentdaoImpl;
	private TutorDaoImpl tutorDao;
	private UserServiceImpl userServiceImpl;
	private AdminServiceImpl adminServiceImpl;   
    public ChangeTutorStatus() {
    	
        super();
        System.out.println("in student servlet");
		
		studentServiceImpl = new StudentServiceImpl();
		studentdaoImpl = new StudentDao();
		tutorDao= new TutorDaoImpl();
		userServiceImpl = new UserServiceImpl();
		adminServiceImpl = new AdminServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String msg = userServiceImpl.changeTutorStaus(Integer.parseInt(request.getParameter("id")));
		RequestDispatcher  rd;
		if(msg.equals("success")) {
			System.out.println("tutor status changed");
			
			 List<Tutor> tutorList = adminServiceImpl.getAllTutor();
			 request.setAttribute("tutorList", tutorList);
			 request.setAttribute("adminName", "admin");
			 rd = request.getRequestDispatcher("view/admin/tutorlist.jsp");
		     rd.include(request, response);

		}
		else {
			System.out.println("student status failed");
			request.setAttribute("msg", "Unable to change status");
			rd = request.getRequestDispatcher("view/admin/tutorlist.jsp");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}		
		
	
}
