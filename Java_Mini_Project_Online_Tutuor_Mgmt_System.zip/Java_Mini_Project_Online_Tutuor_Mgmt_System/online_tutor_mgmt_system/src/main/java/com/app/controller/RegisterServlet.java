package com.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.Role;
import com.app.model.Status;
import com.app.model.Student;
import com.app.model.Tutor;
import com.app.services.StudentServiceImpl;
import com.app.services.UserServiceImpl;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet("/signUp")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private StudentServiceImpl studentServiceImpl;
	private StudentDao studentdaoImpl;
	private TutorDaoImpl tutorDao;
	private UserServiceImpl userServiceImpl;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
    	
        super();
        System.out.println("in sign up servlet");
		
		studentServiceImpl = new StudentServiceImpl();
		studentdaoImpl = new StudentDao();
		tutorDao= new TutorDaoImpl();
		userServiceImpl = new UserServiceImpl();
		
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher  rd;
		if(request.getParameter("role").equals("student"))
		{
			String msg = userServiceImpl.saveStudent(
					new Student(request.getParameter("username"),request.getParameter("email"),
							request.getParameter("pwd"),Role.STUDENT,Status.NOTAPPROVED));
			
			if(msg.equals("success")) {
				request.setAttribute("msg", "Register Successfully..Please Check Your Email to Activate Your Account");
				rd = request.getRequestDispatcher("SignUp.jsp");
				rd.forward(request, response);
			}
			else {
				request.setAttribute("msg", "Unable to Register..Try Again..");
				rd = request.getRequestDispatcher("SignUp.jsp");
				rd.forward(request, response);
			}
		}
		
		if(request.getParameter("role").equals("tutor")) {
			String msg = userServiceImpl.saveTutor(
					new Tutor(request.getParameter("username"),request.getParameter("email"),
							request.getParameter("pwd"),Role.TUTOR,Status.NOTAPPROVED));
			if(msg.equals("success")) {
				request.setAttribute("msg", "Register Successfully..Please Check Your Email to Activate Your Account");
				rd = request.getRequestDispatcher("SignUp.jsp");
				rd.forward(request, response);
			}
			else {
				request.setAttribute("msg", "Unable to Register..Try Again..");
				rd = request.getRequestDispatcher("SignUp.jsp");
				rd.forward(request, response);
			}
		}

		}
		
}
