package com.app.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.NotificationStatus;
import com.app.model.Student;
import com.app.model.Tutor;
import com.app.model.TutorNotification;
import com.app.services.StudentServiceImpl;



/**
 * Servlet implementation class LogOutServlet
 */
@WebServlet("/requestTutor")
public class RequestTutorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private StudentServiceImpl studentServiceImpl;
	private TutorDaoImpl tutorDao;
	
	
  public RequestTutorServlet() {
	  studentServiceImpl = new StudentServiceImpl();
	  tutorDao= new TutorDaoImpl();
  }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		Student student =  studentServiceImpl.getStudent((Integer)session.getAttribute("student_id"));

		Tutor tutor =  tutorDao.getTutor(Integer.parseInt(request.getParameter("id")));
		
		TutorNotification tutorNotification = new TutorNotification(student.getStudId(), tutor.getTutorId(), NotificationStatus.NOTCHECKD);
		String notificationMsg = studentServiceImpl.addTutorNotification(tutorNotification);
		  if(notificationMsg.equals("success")) {
			  
			  String msg = studentServiceImpl.addStudent(student, tutor);
				
				RequestDispatcher rd = request.getRequestDispatcher("getTutorDetails");
				rd.forward(request, response);
		  }
	
	}
	
	
}