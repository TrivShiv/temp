package com.app.controller;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.StudentDao;
import com.app.dao.TutorDaoImpl;
import com.app.model.NotificationStatus;
import com.app.model.Role;
import com.app.model.Student;
import com.app.model.StudentNotification;
import com.app.model.StudentTutorMapping;
import com.app.model.Tutor;
import com.app.model.TutorNotification;
import com.app.services.AdminServiceImpl;
import com.app.services.StudentServiceImpl;
import com.app.services.TutorServiceImpl;
import com.app.services.UserServiceImpl;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet("/acceptStudent")
public class AcceptRequestedStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private StudentServiceImpl studentServiceImpl;
	private StudentDao studentdaoImpl;
	private TutorDaoImpl tutorDaoImpl;
	private UserServiceImpl userServiceImpl;
	private AdminServiceImpl adminServiceImpl;
	private TutorServiceImpl tutorServiceImpl;
	private TutorDaoImpl tutorDao;
    public AcceptRequestedStudentServlet() {
    	
        super();
        System.out.println("in student servlet");
		
		studentServiceImpl = new StudentServiceImpl();
		studentdaoImpl = new StudentDao();
		tutorDaoImpl = new TutorDaoImpl();
		userServiceImpl = new UserServiceImpl();
		adminServiceImpl = new AdminServiceImpl();
		tutorServiceImpl = new TutorServiceImpl();
		tutorDao= new TutorDaoImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in student accept servlet");
		HttpSession session = request.getSession();
		System.out.println("stude Id : "+request.getParameter("studId"));
		System.out.println("tutor id : "+request.getParameter("tutId"));
		int studId = Integer.parseInt(request.getParameter("studId"));
		int tutId = Integer.parseInt(request.getParameter("tutId"));
		System.out.println("session tutor id = "+session.getAttribute("tutor_id"));
		
		Student student =  studentServiceImpl.getStudent(studId);
		Tutor tutor =  tutorDao.getTutor(tutId);
	
		StudentNotification studentNotification = new StudentNotification(student.getStudId(), tutor.getTutorId(), NotificationStatus.NOTCHECKD);
		String notificationMsg = tutorServiceImpl.addStudentNotification(studentNotification);
		  if(notificationMsg.equals("success")) {
			  
			  String msg = tutorServiceImpl.acceptRequestedStudent(studId, tutId);
			  RequestDispatcher rd; 
			  if(msg.equals("success"))
			  {
			  Tutor tutor1 = studentServiceImpl.getTutor(Integer.parseInt(request.getParameter("tutId")));
//			  System.out.println(tutor);
			  Set<StudentTutorMapping> reequestStudentList= studentServiceImpl.getRequestStudentList(tutor1);
			  System.out.println(reequestStudentList);
			  request.setAttribute("requeststudentlist", reequestStudentList );
			  request.setAttribute("tutor_name", tutor1.getTutorName());
			  rd = request.getRequestDispatcher("studentlist.jsp");
			  rd.include(request, response); 
			  } 
			  else
			  { 
			   request.setAttribute("msg","Unable to change status"); 
			   rd = request.getRequestDispatcher("studentlist.jsp");
			  rd.include(request, response);
			  }
		  }
		
		
		   
//		  String msg = tutorServiceImpl.acceptRequestedStudent(studId, tutId);
//		  RequestDispatcher rd; 
//		  if(msg.equals("success"))
//		  {
//		  Tutor tutor = studentServiceImpl.getTutor(Integer.parseInt(request.getParameter("tutId")));
//		  System.out.println(tutor);
//		  Set<StudentTutorMapping> reequestStudentList= studentServiceImpl.getRequestStudentList(tutor);
//		  System.out.println(reequestStudentList);
//		  request.setAttribute("requeststudentlist", reequestStudentList );
//		  request.setAttribute("tutor_name", tutor.getTutorName());
//		  rd = request.getRequestDispatcher("studentlist.jsp");
//		  rd.include(request, response); 
//		  } 
//		  else
//		  { 
//		   request.setAttribute("msg",
//		 "Unable to change status"); rd =
//		  request.getRequestDispatcher("studentlist.jsp");
//		  rd.include(request, response);
//		  }
		 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}		
		
	
}
