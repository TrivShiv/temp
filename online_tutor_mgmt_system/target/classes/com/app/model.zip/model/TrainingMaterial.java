package com.app.model;
import java.time.LocalDateTime;

import javax.persistence.*;

@Entity
@Table(name="training_material")
public class TrainingMaterial {
	@Id
	@Column(name="material_id")
	private int materialId;

	@Column(name="material_title",nullable = false)
	private String materialTitle;

	@Column(name="file_og_name",nullable = false)
	private String fileOgName;

	@Column(name="content_name",nullable = false)
	private String contentName;

	@Column(name="content_type",nullable = false)
	@Lob
	private byte[] contentType;

	@Column(name="created_at",nullable = false)
	private LocalDateTime createdAt;

	@Column(name="modified_at")
	private LocalDateTime modifiedAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="category_id",nullable = false)
	private Category category;

	@ManyToOne()
	@JoinColumn(name ="tutor_id",nullable = false)
	private Tutor tutor;

	public TrainingMaterial(String materialTitle, String fileOgName, String contentName,
			byte[] contentType, LocalDateTime createdAt, Category category, Tutor tutor) {
		super();
		this.materialTitle = materialTitle;
		this.fileOgName = fileOgName;
		this.contentName = contentName;
		this.contentType = contentType;
		this.createdAt = createdAt;
		this.category = category;
		this.tutor = tutor;
	}

	public int getMaterialId() {
		return materialId;
	}

	public void setMaterialId(int materialId) {
		this.materialId = materialId;
	}

	public String getMaterialTitle() {
		return materialTitle;
	}

	public void setMaterialTitle(String materialTitle) {
		this.materialTitle = materialTitle;
	}

	public String getFileOgName() {
		return fileOgName;
	}

	public void setFileOgName(String fileOgName) {
		this.fileOgName = fileOgName;
	}

	public String getContentName() {
		return contentName;
	}

	public void setContentName(String contentName) {
		this.contentName = contentName;
	}

	public byte[] getContentType() {
		return contentType;
	}

	public void setContentType(byte[] contentType) {
		this.contentType = contentType;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getModifiedAt() {
		return modifiedAt;
	}

	public void setModifiedAt(LocalDateTime modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Tutor getTutor() {
		return tutor;
	}

	public void setTutor(Tutor tutor) {
		this.tutor = tutor;
	}

	@Override
	public String toString() {
		return "TrainingMaterial [materialId=" + materialId + ", materialTitle=" + materialTitle + ", fileOgName="
				+ fileOgName + ", contentName=" + contentName + ", createdAt=" + createdAt + ", modifiedAt="
				+ modifiedAt + ", category=" + category + ", tutor=" + tutor + "]";
	}



}
