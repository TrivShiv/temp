package com.app.model;
import java.time.LocalDateTime;

import javax.persistence.*;


@Entity
@Table(name="student_tutor_mapping")
public class StudentTutorMapping {
	@Id
	@GeneratedValue
	@Column(name="student_tutor_id")
	private int studentTutorId;

	@ManyToOne()
	@JoinColumn(name="student_id",nullable = false)
	private Student students;

	@ManyToOne()
	@JoinColumn(name = "tutor_id",nullable = false)
	private Tutor tutors;


	@Enumerated(EnumType.ORDINAL)
	@Column(columnDefinition = "int default 0",nullable = false)
	Status status;

	@Column(name="access_at")
	private LocalDateTime accessAt;

	public StudentTutorMapping(Student students, Tutor tutors) {
		super();
		this.students = students;
		this.tutors = tutors;
	}


	public int getStudentTutorId() {
		return studentTutorId;
	}

	public void setStudentTutorId(int studentTutorId) {
		this.studentTutorId = studentTutorId;
	}

	public Student getStudents() {
		return students;
	}

	public void setStudents(Student students) {
		this.students = students;
	}

	public Tutor getTutors() {
		return tutors;
	}

	public void setTutors(Tutor tutors) {
		this.tutors = tutors;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public LocalDateTime getAccessAt() {
		return accessAt;
	}

	public void setAccessAt(LocalDateTime accessAt) {
		this.accessAt = accessAt;
	}

	@Override
	public String toString() {
		return "StudentTutorMapping [studentTutorId=" + studentTutorId + ", students=" + students + ", tutors=" + tutors
				+ ", status=" + status + ", accessAt=" + accessAt + "]";
	}




}
