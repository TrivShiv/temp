package com.app.model;

public enum Status {
   NOTAPPROVED , APPROVED
}
