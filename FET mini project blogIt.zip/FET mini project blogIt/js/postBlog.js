$("#form3").submit(function (event) {
    console.log("inside function");
    event.preventDefault();
    $.ajax({
        type: "POST",
        url: "http://localhost:3000/blog",
        data: {
          title: $("#blogTitle").val(),
          blogData: $("#edit").val(),
          categoryName: $("#category option:selected").text(),
          image : "",
        //   image : $('input[type="file"]').change(function(e){
        //     var filename = e.target.files[0].name;
        //      console.log("filename :"+filename)
        //     // return e.target.files[0].name;
        // }),
          timestamp : new Date($.now())
        },
        dataType: "json",
        async: true,
        success: function () {
          alert("✅ Successfully registered");
        },
        error: function () {
          alert("❌ Registration Failed");
        },
      });
});