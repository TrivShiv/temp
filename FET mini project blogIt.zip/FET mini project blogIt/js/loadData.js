$('document').ready(function () {
        $.getJSON("http://localhost:3000/blog", function (data) {
                let row = "";
                $.each(data, function (id, blog) {
                row = `
                <div class="card" style="width: 18rem;margin: 10px;">
                <img src="../assets/images/blogCard/${blog.image}" class="card-img-top" alt="image">
                <div class="card-body">
                <h6>${blog.id}</h6>
                <h5 class="card-title" style="color: black;">title : ${blog.title}</h5><br>
                <p class="card-text">blog data : ${blog.blogData}</p>
                <h6 class="card-text" style="color: black;">category name : ${blog.categoryName}</h6>
                <p class="card-text">timestamp : ${blog.timestamp}</p>
                <center>
                <button class="btn btn-primary reading">Continue Reading</button>
                </center>
                </div>
                </div> `;
                
                $('.dashboard_body .row').append(row);
                
                })
                
        });
});