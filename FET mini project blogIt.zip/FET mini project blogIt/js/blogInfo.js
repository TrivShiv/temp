const id = new URLSearchParams(window.location.search).get('id');
console.log("id : "+id);


$('document').ready(function() {
    // event.preventDefault();
    $.ajax({
      type: "GET",
      url: "http://localhost:3000/blog/"+id,
      dataType: "json",
      async: true,
      success: function (data) {
          console.log(data);
          let row ="";
          row = `
          <div class="container">
          <div class="row">
              <div class="col-lg-12">
                  <center>
                      <h1>${data.title}</h1>
                  </center>   
              </div>
          </div>
          <div class="row">
              <div class="col-lg-3">
                  <p>${data.timestamp}</p>   
              </div>
              <div class="col-lg-3">
                  <p>${data.categoryName}</p>   
              </div>
              <div class="col-lg-3">
                  <p>stamp</p>   
              </div>
          </div>
          <div class="row">
              <div class="col-lg-12"><p>${data.blogData}</p></div>
          </div>
          <h6>like</h6>
          <p><textarea name="" id="" cols="30" rows="5"></textarea><button class="btn btn-success">comment</button></p>
          <button class="btn btn-primary" id="like">like</button>
      </div>
          `;
        $('.blogData').append(row);
      },
      error: function () {
        alert("❌ Internel server error");
      },
    });
  });