$("#form1").submit(function (event) {
    event.preventDefault();
    $.ajax({
      type: "GET",
      url: "http://localhost:3000/user?email=" + $("#inputEmail").val(),
      dataType: "json",
      async: true,
      success: function (data) {
          console.log(data);
        if (data[0] !== undefined) {
            console.log("from db.json : "+data[0].password);
            console.log("enterd pwd : "+$("#inputPassword").val());
        if (data[0].password === $("#inputPassword").val()) {
            alert("✅ Login Successful");
            localStorage.userId = data[0].id;
            localStorage.userName = data[0].username;
            window.location.href = "/html/dashboard.html";
          } else {
            alert("😑 You entered wrong password. Please try again!!");
            window.location.href = "/html/login.html";
          }
        } else {
            console.log("😑 Not an user. Please register and then login!!")
          alert("😑 Not an user. Please register and then login!!");
        }
      },
      error: function () {
        alert("❌ Internel server error");
      },
    });
  });


  $("#form2").submit(function (event) {
    event.preventDefault();
    $.ajax({
      type: "GET",
      url: "http://localhost:3000/user?email=" + $("#registerEmail").val(),
      dataType: "json",
      async: true,
      success: function (data) {
          console.log(data)
        if (data[0] == undefined) {
          $.ajax({
            type: "POST",
            url: "http://localhost:3000/user",
            data: {
              username: $("#registerUsername").val(),
              email: $("#registerEmail").val(),
              password: $("#registerPassword").val(),
            },
            dataType: "json",
            async: true,
            success: function () {
              alert("✅ Successfully registered");
            // console.log("success")
            window.location.href = "/html/dashboard.html";
            },
            error: function () {
              alert("❌ Registration Failed");
            },
          });
        }
         else {
          alert(
            "😑 Email id allready taken. Please login or register with other email id!!"
          );
        }
      },
      error: function () {
        alert("❌ Internel server error");
      },
    });
});

