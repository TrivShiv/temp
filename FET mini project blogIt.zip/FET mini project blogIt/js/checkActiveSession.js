$(document).ready(function () {
    // function to check active session
    $('.dashboard_body .row').on('click', '.reading',function(){
      console.log(this);
      console.log("inside read function");
      console.log($($(this).parents('.card-body').children()[0]).html());
      var id = $($(this).parents('.card-body').children()[0]).html();
      if (localStorage.userId !== undefined) {
              window.location.href = "/html/blogInfo.html?id="+id;
            } else {
              window.location.href = "/html/login.html";
            }
  })
});

  